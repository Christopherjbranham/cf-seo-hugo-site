---
title: "Home"
description: "Explore our curated collection of AI automation guides for creators and small businesses."
---

Welcome to our collection of original how‑to guides. Each article explains a simple automation project with free‑tier tools and includes step‑by‑step instructions so you can replicate the workflow without spending anything. Use the search box or browse the guides directory to find a topic that interests you, and feel free to explore – everything here is released under an MIT‑compatible license, so you can learn at your own pace.

To view all guides, go to the **Guides** section in the navigation.