#!/bin/bash

# Cloudflare Pages build script
# This script extracts the site archive and builds the Hugo site.

set -e

ARCHIVE="cf-seo-hugo-site.zip"

if [ -f "$ARCHIVE" ]; then
  echo "Extracting site archive..."
  unzip -o "$ARCHIVE" -d .
fi

echo "Running Hugo build..."
hugo --gc --minify