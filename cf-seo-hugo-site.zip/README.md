# AI Guides Static Site

This repository contains a minimal [Hugo](https://gohugo.io/) site built with a custom MIT‑licensed theme. The site is designed for deployment on [Cloudflare Pages](https://developers.cloudflare.com/pages/) and contains 100 pages of original content about AI‑powered workflows across various topics.

## Cloudflare Pages Configuration

When connecting this repository to Cloudflare Pages, use the following build settings:

- **Framework preset:** `Hugo`
- **Build command:** `hugo --gc --minify`
- **Output directory:** `public`
- **Environment variable:** set `HUGO_VERSION` to a recent stable release (for example `0.128.0`).

These settings ensure that Cloudflare uses the correct Hugo version to build the site.

## GA4 and Affiliate IDs

The file `config.toml` includes placeholders for a GA4 measurement ID and affiliate IDs for Digistore24 and ClickBank. After deployment, update these values and redeploy to enable analytics and affiliate tracking.

## Search Console Verification

To verify the site with Google Search Console using the **URL prefix** method:

1. In Search Console, add a new property for `https://<project>.pages.dev/`.
2. Choose the **HTML file** verification option and download the verification file.
3. Place the downloaded HTML file into the `static/` directory of this repository.
4. Commit and push the file, then redeploy the site.
5. Return to Search Console and click **Verify**.

## License

All original content in this repository is licensed under the MIT License unless otherwise noted. The theme included in `themes/mytheme` is also released under the MIT License.